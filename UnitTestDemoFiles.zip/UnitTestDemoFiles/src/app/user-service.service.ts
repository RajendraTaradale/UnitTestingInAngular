import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor() { }
  addNo(a: number, b: number): any {  
    return a + b;  
 }  
}
