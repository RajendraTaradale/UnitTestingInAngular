import { Component } from '@angular/core';
import {HttpClient, HttpHeaders } from '@angular/common/http'




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';


  /**
   *
   */
//   constructor(private http:HttpClient) {
//    debugger;
//    var headers = new HttpHeaders();

// headers.append('Content-Type', 'application/json');

// headers.append('Access-Control-Allow-Origin', '*');
   
// this.http.post('http://www.agroshan.in/server/index.php?page=user2',null,{responseType: 'text'}).subscribe(function (data:any) {
//       console.log(data);
//       }); 
    
//   }
}
