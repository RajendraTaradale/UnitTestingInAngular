import { TestBed, inject } from '@angular/core/testing';

import { UserServiceService } from './user-service.service';

describe('UserServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UserServiceService]
    });
  });

  it('should be created', inject([UserServiceService], (service: UserServiceService) => {
    expect(service).toBeTruthy();
  }));

  it('Service: addNo exisit', inject([UserServiceService], (service: UserServiceService) => {
    expect(service.addNo).toBeTruthy();
  }));

  it('Service: Addition of two numbers', inject([UserServiceService], (service: UserServiceService) => {
    expect(service.addNo(50,50)).toBe(100);
  }));

});
