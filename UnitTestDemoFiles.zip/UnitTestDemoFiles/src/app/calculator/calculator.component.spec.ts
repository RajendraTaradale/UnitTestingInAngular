import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CalculatorComponent } from './calculator.component';
describe('CalculatorComponent', () => {

  let component: CalculatorComponent;
  let fixture: ComponentFixture<CalculatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalculatorComponent ]
    })
    .compileComponents();
  }));
    beforeEach(() => {
        fixture = TestBed.createComponent(CalculatorComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });
  
  it('Add two numders', () => {
    debugger;  
    component.addNo(10,20);  
    expect(component.result).toBe(30);  
});  

});

describe('Testing No state in Calculator component', () => {  
  debugger;  
  let app: CalculatorComponent;  

  beforeEach(() => {  
      app = new CalculatorComponent();  
  });  
  it('new should set new no', () => {  
      app.addNo(10,20);  
      expect(app.result).toBe(30);  
  });  

});  