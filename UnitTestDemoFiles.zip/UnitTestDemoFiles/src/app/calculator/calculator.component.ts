import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent  {

  public result: number = 0;  
  
    constructor() { }  
  
    addNo(a: number, b: number): any {  
        this.result = a + b;  
    }  
  
    clear() {  
        this.result = 0;  
    }  
}
